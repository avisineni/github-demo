# Hybrid Comprehensive Assessment

Clone the repo and use `maven test` to run the project
