package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class UtilityException extends Exception {
	public UtilityException(String msg) {
		super(msg);
	}

}
