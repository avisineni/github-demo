package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class PageObjectException extends Exception {

	public PageObjectException(String msg) {
		super(msg);
	}

}
